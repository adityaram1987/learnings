package com.config.sample.main;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Configuration
public class ReadPropertiesFile {

	@Value("${app.name}")
	public String name;
	
	public void testing() {
		System.out.println("testing " + name);
	}
}
